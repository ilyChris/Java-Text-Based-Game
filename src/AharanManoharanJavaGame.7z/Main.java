import java.util.Scanner;
import java.util.Random;
public class Main {
    Scanner playerInput = new Scanner(System.in);

    public int batmanHP;
    public String batmanSuit;
    public int option;
    public String playerVerbInput;
    public int jokerHP;

    //boolean upgradedSuit ;
    //boolean batarang ;
    //boolean westRoomLock ;


    public static void main(String[] args) {
        GameSetUp newGame = new GameSetUp();
        newGame.GameSetUp();
	 /* ATTEMPTED TO MAKE BOOLEAN STATEMENTS WHICH WOULD PREVENT ACCESS TO THE WEST ROOM DEPENDING ON IF
        THE PLAYER HAD FOUND AND USED BATARANGS ON THE LOCK FOR THE ROOM. I COULD NOT GET IT TO WORK.
         */
    }
}

public class Win {
    public void winGame(){
        System.out.println("You defeat Joker and rescue Jim Gordon.");
        System.out.println("YOU WON");
    }
}

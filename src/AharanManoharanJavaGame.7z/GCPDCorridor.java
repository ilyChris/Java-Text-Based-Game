public class GCPDCorridor extends GCPDEntrance{
    //private boolean upgradedSuit;
    //private boolean westRoomLock;
    //private boolean batarang;

    /*public boolean getBatarang(){
                return batarang;
    }
    public void setBatarang(){
        this.batarang = true;
    }

    public boolean getUpgradedSuit(){
        return upgradedSuit;
    }
    public void setUpgradedSuit(){
        this.upgradedSuit = true;
    }

    public boolean getWestRoomLock(){
        return westRoomLock;
    }
    public void setWestRoomLock(){
        this.westRoomLock = true;
    }
*/

    public void GCPDCorridor(){
        System.out.println("-----------------------------------------------------------------");

        System.out.println("Which way would you like to go?");
        System.out.println("north");
        System.out.println("east");
        System.out.println("south");
        System.out.println("west");
        System.out.println("Enter a direction of movement");

        playerVerbInput = playerInput.nextLine();

        /* ATTEMPTED TO MAKE BOOLEAN STATEMENTS WHICH WOULD PREVENT ACCESS TO THE WEST ROOM DEPENDING ON IF
        THE PLAYER HAD FOUND AND USED BATARANGS ON THE LOCK FOR THE ROOM. I COULD NOT GET IT TO WORK.
         */

        if(playerVerbInput.equals("north")){
            /*if(getUpgradedSuit()==true){
                System.out.println("You have no reason to go back in this room");
                GCPDCorridor();
            }
            else {
                NorthGCPD getBatsuit = new NorthGCPD();
                getBatsuit.puzzle();
            }*/
            NorthGCPD getBatsuit = new NorthGCPD();
            getBatsuit.puzzle();
        }
        else if(playerVerbInput.equals("east")){
            /*if(getWestRoomLock()==true){
                System.out.println("You have done all there is to do in this room");
                GCPDCorridor();
            }
            else {
                EastGCPD unlockBoss = new EastGCPD();
                unlockBoss.unlockWest();
            }*/
            EastGCPD unlockBoss = new EastGCPD();
            unlockBoss.unlockWest();

        }
        else if(playerVerbInput.equals("south")){
            /*if(getBatarang()==true){
                System.out.println("You have no reason to go back here");
                GCPDCorridor();
            }
            else {
                SouthGCPD getBatarang = new SouthGCPD();
                getBatarang.acquireBatarangs();
            }*/
            SouthGCPD getBatarang = new SouthGCPD();
            getBatarang.acquireBatarangs();

        }
        else if(playerVerbInput.equals("west")){
            /*if(getWestRoomLock()==true){
                System.out.println("You can hear the Joker laughing from outside the room");
                System.out.println("The door is unlocked and you enter the room");
                WestGCPD bossFight = new WestGCPD();
                bossFight.fightJoker();
            }
            else{
                System.out.println("You can hear the Joker laughing from outside the room");
                System.out.println("The door is locked and you can't seem to enter");
                System.out.println("You need to find a way into this room fast before Joker kills Jim");
                GCPDCorridor();
            }*/
            System.out.println("You can hear the Joker laughing from outside the room");
            System.out.println("The door is unlocked and you enter the room");
            WestGCPD bossFight = new WestGCPD();
            bossFight.fightJoker();

        }
        else {
            GCPDCorridor();
        }


    }
}
